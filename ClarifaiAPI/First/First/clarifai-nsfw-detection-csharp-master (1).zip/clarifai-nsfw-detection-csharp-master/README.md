# clarifai-nsfw-detection-csharp
clarifai nsfw image detection implementation for c# 

[screenshot](http://i.imgur.com/HCyVLbY.png)
